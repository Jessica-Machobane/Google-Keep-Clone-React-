import React from 'react';

interface KeepLogoProps {
  className?: string;
  size?: number;
}

export const KeepLogo: React.FC<KeepLogoProps> = ({ className = '', size = 40 }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      fill="none"
      viewBox="0 0 192 192"
      className={className}
    >
      <mask
        id="keep-mask-b"
        width="140"
        height="140"
        x="26"
        y="8"
        maskUnits="userSpaceOnUse"
        style={{ maskType: 'alpha' }}
      >
        <path
          fill="url(#keep-grad-a)"
          d="M166 78c0 27.13-15.434 50.381-38 62-9.591 4.938-20.47 8-32 8s-22.41-3.062-32-8c-22.566-11.619-38-34.87-38-62C26 39.34 57.34 8 96 8s70 31.34 70 70"
        />
      </mask>
      <g mask="url(#keep-mask-b)">
        <circle cx="96" cy="78" r="70" fill="url(#keep-grad-c)" />
        <g filter="url(#keep-filter-d)">
          <path
            fill="#fdfd6d"
            d="M52 124c0-38.137 14.81-60 44-60s44 21.863 44 60c0 33.137-19.699 60-44 60s-44-26.863-44-60"
          />
        </g>
        <g filter="url(#keep-filter-e)">
          <path
            fill="url(#keep-grad-f)"
            d="M64 102c0-17.673 14.327-32 32-32s32 14.327 32 32v52c0 17.673-14.327 32-32 32s-32-14.327-32-32z"
          />
        </g>
        <path
          fill="#fff"
          d="M78 127c0-7.18 5.82-13 13-13h10c7.18 0 13 5.82 13 13s-5.82 13-13 13H91c-7.18 0-13-5.82-13-13"
        />
      </g>
      <mask
        id="keep-mask-g"
        width="80"
        height="46"
        x="56"
        y="140"
        maskUnits="userSpaceOnUse"
        style={{ maskType: 'alpha' }}
      >
        <path fill="#ffbe00" d="M56 140h80v46H56z" />
      </mask>
      <g mask="url(#keep-mask-g)">
        <path
          fill="#f6a100"
          d="M96 56c-18.4 0-32 14.4-32 33.6v62.8c0 19.2 13.6 33.6 32 33.6s32-14.4 32-33.6V89.6C128 70.4 114.4 56 96 56"
        />
      </g>
      <defs>
        <linearGradient
          id="keep-grad-a"
          x1="71.83"
          x2="156.83"
          y1="148"
          y2="8"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset=".1" stopColor="#ffe921" />
          <stop offset=".48" stopColor="#fdd313" />
          <stop offset=".86" stopColor="#ffbe00" />
        </linearGradient>
        <linearGradient
          id="keep-grad-c"
          x1="96"
          x2="96"
          y1="140.04"
          y2="8"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset=".16" stopColor="#ffe921" />
          <stop offset=".64" stopColor="#fec700" />
          <stop offset=".96" stopColor="#ffbe00" />
        </linearGradient>
        <linearGradient
          id="keep-grad-f"
          x1="96"
          x2="96"
          y1="51.19"
          y2="142.89"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset=".11" stopColor="#ffb8dd" stopOpacity="0" />
          <stop offset=".68" stopColor="#ffb5e8" />
        </linearGradient>
        <filter
          id="keep-filter-d"
          width="203.2"
          height="235.2"
          x="-5.6"
          y="6.4"
          colorInterpolationFilters="sRGB"
          filterUnits="userSpaceOnUse"
        >
          <feFlood floodOpacity="0" result="BackgroundImageFix" />
          <feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur result="effect1_foregroundBlur" stdDeviation="28.8" />
        </filter>
        <filter
          id="keep-filter-e"
          width="88"
          height="140"
          x="52"
          y="58"
          colorInterpolationFilters="sRGB"
          filterUnits="userSpaceOnUse"
        >
          <feFlood floodOpacity="0" result="BackgroundImageFix" />
          <feBlend in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
          <feGaussianBlur result="effect1_foregroundBlur" stdDeviation="6" />
        </filter>
      </defs>
    </svg>
  );
};
